package WildFarm;

public abstract class Feline extends Mammal {

    protected Feline(String animalName, String animalType, Double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }
}
