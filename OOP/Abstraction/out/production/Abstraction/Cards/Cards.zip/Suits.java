package Cards;

public enum Suits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
